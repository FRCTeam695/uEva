package frc.robot.subsystems;

public class MotorType {

}
